var config = {
    apiKey: "AIzaSyBo4IbsDqu0JYvVVAp05vG1cZ0WdYBZPJc",
    authDomain: "carpoolniit.firebaseapp.com",
    databaseURL: "https://carpoolniit.firebaseio.com",
    projectId: "carpoolniit",
    storageBucket: "carpoolniit.appspot.com",
    messagingSenderId: "164446428246"
  };
  firebase.initializeApp(config);
